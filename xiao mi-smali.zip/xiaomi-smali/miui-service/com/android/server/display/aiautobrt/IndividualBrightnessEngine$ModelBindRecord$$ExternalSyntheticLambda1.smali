# classes.dex

.class public final synthetic Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;

.field public final synthetic f$1:Landroid/os/IBinder;


# direct methods
.method public synthetic constructor <init>(Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;Landroid/os/IBinder;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord$$ExternalSyntheticLambda1;->f$0:Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;

    iput-object p2, p0, Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord$$ExternalSyntheticLambda1;->f$1:Landroid/os/IBinder;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord$$ExternalSyntheticLambda1;->f$0:Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;

    iget-object v1, p0, Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord$$ExternalSyntheticLambda1;->f$1:Landroid/os/IBinder;

    invoke-static {v0, v1}, Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;->$r8$lambda$2SjTiiWlZKgMzaT1CLd-WdImNKY(Lcom/android/server/display/aiautobrt/IndividualBrightnessEngine$ModelBindRecord;Landroid/os/IBinder;)V

    return-void
.end method

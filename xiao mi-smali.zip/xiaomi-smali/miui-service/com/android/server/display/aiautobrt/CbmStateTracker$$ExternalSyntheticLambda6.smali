# classes.dex

.class public final synthetic Lcom/android/server/display/aiautobrt/CbmStateTracker$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/server/display/aiautobrt/CbmStateTracker;


# direct methods
.method public synthetic constructor <init>(Lcom/android/server/display/aiautobrt/CbmStateTracker;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/server/display/aiautobrt/CbmStateTracker$$ExternalSyntheticLambda6;->f$0:Lcom/android/server/display/aiautobrt/CbmStateTracker;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/android/server/display/aiautobrt/CbmStateTracker$$ExternalSyntheticLambda6;->f$0:Lcom/android/server/display/aiautobrt/CbmStateTracker;

    invoke-static {v0}, Lcom/android/server/display/aiautobrt/CbmStateTracker;->$r8$lambda$Z2NGCPuh_lPxjoVuNwc93Ba18Y0(Lcom/android/server/display/aiautobrt/CbmStateTracker;)V

    return-void
.end method

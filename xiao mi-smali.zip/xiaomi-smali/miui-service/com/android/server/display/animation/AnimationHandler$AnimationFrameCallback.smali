# classes.dex

.class interface abstract Lcom/android/server/display/animation/AnimationHandler$AnimationFrameCallback;
.super Ljava/lang/Object;
.source "AnimationHandler.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/server/display/animation/AnimationHandler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "AnimationFrameCallback"
.end annotation


# virtual methods
.method public abstract doAnimationFrame(J)Z
.end method

# classes.dex

.class public final synthetic Lcom/android/server/display/TouchCoverProtectionHelper$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/android/server/display/TouchCoverProtectionHelper;


# direct methods
.method public synthetic constructor <init>(Lcom/android/server/display/TouchCoverProtectionHelper;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/server/display/TouchCoverProtectionHelper$$ExternalSyntheticLambda1;->f$0:Lcom/android/server/display/TouchCoverProtectionHelper;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/android/server/display/TouchCoverProtectionHelper$$ExternalSyntheticLambda1;->f$0:Lcom/android/server/display/TouchCoverProtectionHelper;

    invoke-static {v0}, Lcom/android/server/display/TouchCoverProtectionHelper;->$r8$lambda$eheL7RcUwIe8iGlv0o5OV7zXVok(Lcom/android/server/display/TouchCoverProtectionHelper;)V

    return-void
.end method
